package com.home.currency;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText ntd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
    }

    private void findViews(){
        ntd = findViewById(R.id.ntd);
    }
    public void to_us(View view) {
        String str_ntd = ntd.getText().toString();
        String str_tile = "";
        String str_message = "";
        if (str_ntd.isEmpty())   {
            str_tile = "Program";
            str_message = "Please enter your NTD amount";
        }
        else {
            float ntd = Float.parseFloat(str_ntd);
            float us = ntd / 30.9f;
            str_tile = "Result";
            str_message = "USD is " + us;
        }
        new AlertDialog.Builder(this)
                .setTitle(str_tile)
                .setMessage(str_message)
                .setPositiveButton("OK", null)
                .show();
    }

}
